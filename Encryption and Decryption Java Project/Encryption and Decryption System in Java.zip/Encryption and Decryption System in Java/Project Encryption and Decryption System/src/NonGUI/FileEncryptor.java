
package NonGUI;
/**
 *
 * @GK
 */
import java.io.*;
public class FileEncryptor {
    private static int key = 0; // Default key
    public static void encryptFile(File inputFile, File outputFile) throws IOException {
        if (key == 0) {
            throw new IllegalStateException("Encryption key not set");
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            int data;
            while ((data = reader.read()) != -1) {
                char encryptedChar = (char) (data + key);
                writer.write(encryptedChar);
            }
        }
    }
    public static void decryptFile(File inputFile, File outputFile) throws IOException {
        if (key == 0) {
            throw new IllegalStateException("Encryption key not set");
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            int data;
            while ((data = reader.read()) != -1) {
                char decryptedChar = (char) (data - key);
                writer.write(decryptedChar);
            }
        }
    }
    public static int getEncryptionKey() {
        return key;
    }
    public static void setEncryptionKey(int newKey) {
        key = newKey;
    }
}
