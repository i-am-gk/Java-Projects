package GUI;
/**
 *
 * @GK
 */
import NonGUI.FileEncryptor;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileReader;
public class FileOperationGUI extends JFrame implements ActionListener {
    // Buttons for various operations
    private JButton chooseFileButton, encryptButton, decryptButton, exitButton, detailsButton,
    overviewButton, reasonButton, ftButton, benefitsButton, feedbackButton, fileInformationButton,useage;
    private JFileChooser fileChooser;
    private File selectedFile;
    /**
     * Constructor to set up the main frame of the application.
     */
    public FileOperationGUI() {
        super("Encryption and Decryption Project");
        setSize(900, 700); // Increased height to accommodate the image
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Create buttons with styling
        chooseFileButton = createStyledButton("Choose Your File");
        encryptButton = createStyledButton("Encrypt File");
        decryptButton = createStyledButton("Decrypt File");
        exitButton = createStyledButton("Exit");
        detailsButton = createStyledButton("Details");
        overviewButton = createStyledButton("Overview");
        reasonButton = createStyledButton("Why This Project");
        ftButton = createStyledButton("Future Work");
        benefitsButton = createStyledButton("Benefits");
        feedbackButton = createStyledButton("Provide Remarks");
        fileInformationButton = createStyledButton("File Information");
        useage= createStyledButton("Synopsis");
        
        // Add action listeners to the buttons
        chooseFileButton.addActionListener(this);
        encryptButton.addActionListener(this);
        decryptButton.addActionListener(this);
        exitButton.addActionListener(this);
        detailsButton.addActionListener(this);
        overviewButton.addActionListener(this);
        reasonButton.addActionListener(this);
        ftButton.addActionListener(this);
        benefitsButton.addActionListener(this);
        feedbackButton.addActionListener(this);
        fileInformationButton.addActionListener(this);
        useage.addActionListener(this);
        
        // Set up file chooser with a filter for text files
        fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Text Files", "txt", "rtf"));

        // Create a panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 10, 10, 20)); // Grid layout for buttons

        // Add buttons to the panel
        buttonPanel.add(chooseFileButton);
        buttonPanel.add(encryptButton);
        buttonPanel.add(decryptButton);
        buttonPanel.add(detailsButton);
        buttonPanel.add(overviewButton);
        buttonPanel.add(reasonButton);
        buttonPanel.add(ftButton);
        buttonPanel.add(benefitsButton);
        buttonPanel.add(feedbackButton);
        buttonPanel.add(fileInformationButton);
        buttonPanel.add(useage);
        buttonPanel.add(exitButton);

        // Add the button panel to the top of the frame
        add(buttonPanel, BorderLayout.NORTH);

        // Add an image below the buttons
        ImageIcon imageIcon = new ImageIcon("D:\\New folder (3)\\cyber-security-blog-min.jpg");
        JLabel imageLabel = new JLabel(imageIcon);
        add(imageLabel, BorderLayout.CENTER);

        // Set background color of the frame
        getContentPane().setBackground(Color.BLACK);
        setVisible(true);
    }

    /**
     * Helper method to create styled buttons with a gradient background.
     */
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(150, 50)); // Set preferred size
        button.setFont(new Font("Arial", Font.BOLD, 14)); // Set font
        button.setFocusPainted(false); // Remove the focus border

        // Create a gradient background
        GradientPaint gradientPaint = new GradientPaint(
         0, 0, new Color(51, 153, 255), 150, 50, new Color(0, 102, 204));
        button.setOpaque(true);
        button.setBackground(new Color(51, 153, 255));
        button.setForeground(Color.BLACK);
        button.setBorderPainted(false);

        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
           // Changes the background color to dark blue when the mouse enters the button.
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0, 102, 204));
            }
//Reverts the background color to light blue when the mouse exits the button.
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(51, 153, 255));
            }
        });

        return button;
    }

    /**
     * ActionListener implementation to handle button clicks.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle button clicks based on the source
        if (e.getSource() == chooseFileButton) {
            chooseFile();
        } else if (e.getSource() == encryptButton) {
            encryptFile();
        } else if (e.getSource() == decryptButton) {
            decryptFile();
        } else if (e.getSource() == detailsButton) {
            showDetails();
        } else if (e.getSource() == overviewButton) {
            showOverview();
        } else if (e.getSource() == reasonButton) {
            showReason();
        } else if (e.getSource() == ftButton) {
            showFutureWork();
        } else if (e.getSource() == benefitsButton) {
            showBenefitsofEncryption();
        } else if (e.getSource() == feedbackButton) {
            provideFeedback();
        } else if (e.getSource() == fileInformationButton) {
            showFileInformation();
        } else if (e.getSource() == exitButton) {
            System.exit(0);
        }
        else if (e.getSource() == useage){
           openFileForReading();
        }
    }
    private void chooseFile() {
        // Show the file chooser dialog and capture the user's selection
        int result = fileChooser.showOpenDialog(this);
        // Check if the user selected a file
        if (result == JFileChooser.APPROVE_OPTION) {
            // Retrieve the selected file
            selectedFile = fileChooser.getSelectedFile();
            // Display a message indicating the selected file
            JOptionPane.showMessageDialog(this, "File Selected: " + selectedFile.getName());
        }
    }
private void encryptFile() {
    if (selectedFile != null) {
        // Prompt the user for the encryption key
        String keyInput = JOptionPane.showInputDialog(this, "Enter Encryption Key:");
        if (keyInput != null && !keyInput.isEmpty()) {
            try {
                int key = Integer.parseInt(keyInput);
                FileEncryptor.setEncryptionKey(key);
                // Choose the output file for encrypted content
                fileChooser.setSelectedFile(new File("encrypted_" + selectedFile.getName()));
                int result = fileChooser.showSaveDialog(this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File encryptedFile = fileChooser.getSelectedFile();

                    try {
                        // Perform encryption
                        FileEncryptor.encryptFile(selectedFile, encryptedFile);
                        JOptionPane.showMessageDialog(this, "File Encrypted and Saved as: " + encryptedFile.getName());
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(this, "Error during encryption", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid key. Encryption canceled.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid key. Encryption canceled.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please choose a file first", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void decryptFile() {
    if (selectedFile != null) {
        // Prompt the user for the decryption key
        String keyInput = JOptionPane.showInputDialog(this, "Enter Decryption Key:");

        if (keyInput != null && !keyInput.isEmpty()) {
            try {
                int key = Integer.parseInt(keyInput);
                FileEncryptor.setEncryptionKey(key);

                // Choose the output file for decrypted content
                fileChooser.setSelectedFile(new File("decrypted_" + selectedFile.getName()));
                int result = fileChooser.showSaveDialog(this);

                if (result == JFileChooser.APPROVE_OPTION) {
                    File decryptedFile = fileChooser.getSelectedFile();
                    try {
                        // Perform decryption
                        FileEncryptor.decryptFile(selectedFile, decryptedFile);
                        JOptionPane.showMessageDialog(this, "File Decrypted and Saved as: " + decryptedFile.getName());
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(this, "Error during decryption", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid key. Decryption canceled.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid key. Decryption canceled.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please choose a file first", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    private void provideFeedback() {
        // Create a custom JPanel to hold the feedback components
        JPanel feedbackPanel = new JPanel(new BorderLayout());
        // Add a JLabel with a stylish font to prompt the user for feedback
        JLabel promptLabel = new JLabel("Share your thoughts:");
        promptLabel.setFont(new Font("Arial", Font.BOLD, 14));
        feedbackPanel.add(promptLabel, BorderLayout.NORTH);
        // Add a JTextArea for the user to type their feedback
        JTextArea feedbackTextArea = new JTextArea(5, 30);
        feedbackTextArea.setLineWrap(true);
        feedbackTextArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(feedbackTextArea);
        feedbackPanel.add(scrollPane, BorderLayout.CENTER);
        // Show a custom dialog with the feedbackPanel
        int option = JOptionPane.showOptionDialog(this, feedbackPanel,
                "Feedback", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, null, null);
        // Process the user's feedback based on their choice
        if (option == JOptionPane.OK_OPTION && !feedbackTextArea.getText().trim().isEmpty()) {
            // Process or store the feedback as needed
            String feedback = feedbackTextArea.getText();
            JOptionPane.showMessageDialog(this, "Thank you for your valuable feedback:\n" + feedback,
                    "Feedback Received", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "No feedback provided.", "Feedback",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
    public void showDetails() {
        JFrame detailsFrame = new JFrame("About the Program");
        detailsFrame.setSize(400, 200);
        detailsFrame.setLocationRelativeTo(null);
        detailsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // Set the background color of the JFrame
        detailsFrame.getContentPane().setBackground(new Color(240, 240, 240)); // Light gray
        JTextArea detailsTextArea = new JTextArea();
        detailsTextArea.setText("\tThis Program is Made By\n\n" +
                " Ghani Abdul Rehman Khan\n\n SE 3C\n\n Sir Jazib e Nazar\n\n FA22-BSE-153");
        // Set the background color of the JTextArea
        detailsTextArea.setBackground(new Color(240, 240, 240)); // Light gray
        // Set the text color of the JTextArea
        detailsTextArea.setForeground(Color.BLACK); // Black
        detailsTextArea.setEditable(false);
        detailsTextArea.setWrapStyleWord(true);
        detailsTextArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(detailsTextArea);
        detailsFrame.add(scrollPane);
        detailsFrame.setVisible(true);
    }
private void showFileInformation() {
    if (selectedFile != null) {
        String fileInfo = "File Name: " + selectedFile.getName() + "\n" +
                "File Size: " + selectedFile.length() + " bytes\n" +
                "File Path: " + selectedFile.getPath()+"\n" +
                "Can File Be exceuted: " + selectedFile.canExecute()+ "\n" +
                "Can File Be Read: " + selectedFile.canRead()+ "\n" +
                "Can File Be Over Writen: " + selectedFile.canWrite();
        JOptionPane.showMessageDialog(this, fileInfo, "File Information", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(this, "Please choose a file first", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    private void showOverview() {
        String message = """
   The Java Encryption and Decryption project is a robust and versatile
   solution designed to secure sensitive data through advanced cryptographic techniques.
   This project aims to provide a user-friendly and efficient way to encrypt
   and decrypt information, ensuring the confidentiality and integrity of data.
    Key Features:
     1. Encryption Algorithm
     2. Decryption Capability
     3. Key Management
     4. File and Text Encryption
     5. User Authentication""";
        JOptionPane.showMessageDialog(this, message, "Project Overview", JOptionPane.INFORMATION_MESSAGE);
    }
    public void showReason() {
        String message = """
  Reasons for Choosing the Project:
  The decision to undertake the Encryption and Decryption System project stems from a recognition
  of the growing need for data security in various domains, including personal communication,
  financial transactions, and confidential business information.
  As technology continues to advance, the risk of data breaches also increases, making encryption a crucial
  tool in the arsenal against cyber threats.""";

        JOptionPane.showMessageDialog(this, message, "Show Reason", JOptionPane.INFORMATION_MESSAGE);
    }
    public void showFutureWork() {
        String message = """
                         Future Work:
                         
    The Encryption and Decryption System project lays the foundation for future enhancements and expansions.
     Some potential areas for future work include:
    1. Advanced Encryption Algorithms:
       Explore and implement more advanced encryption algorithms to stay ahead of evolving cyber threats.
    2. Integration with Cloud Services:
       Investigate the integration of the system with cloud services for secure data storage and sharing.
    3. Multi-Platform Compatibility:
       Develop versions of the system for different platforms 
      (e.g., mobile devices, web applications) to cater to a wider user base.""";

        JOptionPane.showMessageDialog(this, message, "Project Overview", JOptionPane.INFORMATION_MESSAGE);

    }
    public void showBenefitsofEncryption() {
        String message = """
                         Benefits of Encryption:
                         
                         1. Data Confidentiality:
                            Encryption ensures that only authorized individuals can access sensitive information,
                          maintaining data confidentiality.
                         2. Protection Against Cyber Threats:
                            The project serves as a defense mechanism against various cyber threats, including data
                          breaches and unauthorized access.
                         3. Compliance with Data Protection Regulations:
                            Adherence to encryption standards helps meet regulatory requirements
                          and data protection laws.""";

        JOptionPane.showMessageDialog(this, message, "Project Overview", JOptionPane.INFORMATION_MESSAGE);
    }
  public void openFileForReading() {
    String filePath = "D:\\File\\File1.rtf";
    try (FileReader reader = new FileReader(filePath)) {
        JEditorPane editorPane = new JEditorPane();
        editorPane.setContentType("text/rtf");
        // Read the RTF content into the editor pane
        editorPane.read(reader, null);
        // Disable editing
        editorPane.setEditable(false);
        // Display the content in a scrollable dialog
        JScrollPane scrollPane = new JScrollPane(editorPane);
        scrollPane.setPreferredSize(new Dimension(600, 400));
        JOptionPane.showMessageDialog(this, scrollPane, "File Reading", JOptionPane.INFORMATION_MESSAGE);

    } catch (FileNotFoundException e) {
        JOptionPane.showMessageDialog(this, "File not found: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error reading the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

}
   public static void main(String[] args) {
                new FileOperationGUI().setVisible(true);
            }
}
        