
package GUI;
/**
 *
 * @GK
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.EmptyBorder;
public class LoginFrame extends JFrame {
    private int loginAttempts = 3; // Number of login attempts allowed
    private JPasswordField usernameField;
    private JPasswordField passwordField;
    public LoginFrame() {
        // Set frame properties
        setTitle("User Authentication System");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame

        // Set background image
        String imagePath = "C:/Users/vines/Downloads/New folder/Untitled.jpg";
        setContentPane(new JLabel(new ImageIcon(imagePath)));
        setLayout(new BorderLayout());

        // Welcome label
        JLabel welcomeLabel = new JLabel(" USER AUTHENTICATION REQUIRED", SwingConstants.CENTER);
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 26)); // Increase font size
        welcomeLabel.setBorder(new EmptyBorder(10, 0, 10, 0));
        add(welcomeLabel, BorderLayout.NORTH);

        // Credentials panel
        JPanel credentialsPanel = new JPanel();
        credentialsPanel.setOpaque(false);
        credentialsPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Add some padding

        // Username field (Modified to JPasswordField)
        usernameField = new JPasswordField(20); // Reduced width
        JLabel usernameLabel = new JLabel("USERNAME:");
        usernameLabel.setForeground(Color.BLACK);
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 14)); // Set the desired font size
        credentialsPanel.add(usernameLabel, gbc);
        gbc.gridy = 1;
        credentialsPanel.add(usernameField, gbc);

        // Password field
        passwordField = new JPasswordField(20); // Reduced width
        JLabel passwordLabel = new JLabel("PASSWORD:");
        passwordLabel.setForeground(Color.BLACK);
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14)); 
       // placing the label in the third row of the layout
        gbc.gridy = 2;
        credentialsPanel.add(passwordLabel, gbc);
        gbc.gridy = 3;
        credentialsPanel.add(passwordField, gbc);

        // Login button
        JButton loginButton = new JButton("Login");
        loginButton.setBackground(new Color(76, 175, 80)); // Unique color
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD, 16)); // Increase font size
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String enteredUsername = new String(usernameField.getPassword());
                char[] enteredPasswordChars = passwordField.getPassword();
                String enteredPassword = new String(enteredPasswordChars);

                // Check if the entered credentials are valid
                if (enteredUsername.equals("comsis") && enteredPassword.equals("12345")) {
                    // Successful login, open FileOperationGUI
                    dispose(); // Close the current login frame
            new FileOperationGUI().setVisible(true);
                } else {
                    // Decrement the login attempts
                    loginAttempts--;

                    if (loginAttempts > 0) {
                        // Display the remaining chances
                        JOptionPane.showMessageDialog(LoginFrame.this,
                                "Invalid Credentials. You have " + loginAttempts +
                                        " chances left. Please try again.");
                        resetLoginFrame();
                    } else {
                        // No more chances, display a message and close the login frame
                        JOptionPane.showMessageDialog(LoginFrame.this,
                                "Your chances are over. The application will now close.");
                        System.exit(0); // Terminate the application
                    }
                }
            }

            // Method to reset the login frame
            private void resetLoginFrame() {
                usernameField.setText(""); // Clear the username field
                passwordField.setText(""); // Clear the password field
            }
        });
        gbc.gridy = 4;
        credentialsPanel.add(loginButton, gbc);
        add(credentialsPanel, BorderLayout.CENTER);

        // Welcome message label at the bottom
        JLabel welcomeMessageLabel = new JLabel("ENTER YOUR CREDENTIALS", SwingConstants.CENTER);
        welcomeMessageLabel.setForeground(Color.WHITE);
        welcomeMessageLabel.setFont(new Font("Arial", Font.BOLD, 20)); // Set the desired font size
        add(welcomeMessageLabel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
    
                new LoginFrame().setVisible(true);
            }
}

